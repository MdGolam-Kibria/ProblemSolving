package com.problemSolving;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProblemSolvingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProblemSolvingApplication.class, args);
	}

}
